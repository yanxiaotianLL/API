﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using DependencyRegister;
using FS.Common;
using FS.Common.Extensions;
using FS.Component.Cache;
using FS.Component.Logging;
using FS.Config;
using FS.Core.API.Extensition;
using FS.Core.API.Models;
using LitJson2;
using FS.Model.Extensition;

namespace FS.Core.API.MessageHandler
{
    /**********************************************************************************
     *项目名称	：FS.Core.API.MessageHandler
     *项目描述  ：
     *类名称    ：SignCheckMessageHandler
     *版本号    ：v1.0.0
     *机器名称  ：LIUYONG-PC
     *项目名称  : SignCheckMessageHandler
     *CLR版本   : 4.0.30319.42000
     *作者      ：liu.yong
     *创建时间  : 2016/12/30 23:41:39
     *------------------------------------变更记录--------------------------------------
     *变更描述  :
     *变更作者  :
     *变更时间  :
    ***********************************************************************************/
    public class SignCheckMessageHandler : DelegatingHandler
    {
        private ServiceAccount serviceAccount = null;
        private string appsecret = "dc79116859df79db9c7c77ed923a3703";
        protected  override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
        {
            List<KeyValuePair<string, string>> paramDic = new List<KeyValuePair<string, string>>();

            string content = string.Empty;
            //获取参数
            #region 判断请求类型
            //判断请求类型
            if (request.Method == HttpMethod.Get)
            {
                var query = request.GetQueryNameValuePairs();
                #region AppAccount参数校验
                //AppAccount参数校验
                if (query.Any(a => a.Key == SignParamter.AppAccount) && query.Single(s => s.Key == SignParamter.AppAccount).Value.ToUpper() == "NetworkApp".ToUpper())
                {
                    paramDic.Add(request.GetQueryNameValuePairs().GetParamter(SignParamter.AppAccount));
                }
                else
                {
                    var message = request.CreateResponse(new ResponseBase<object>()
                    {
                        Code = "1",
                        Data = null,
                        Message = "请传递正确的AppAccount参数！",
                        Success = false
                    });
                    message.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(message);
                   


                } 
                #endregion
                #region Noncestr参数校验
                //Noncestr参数校验
                if (query.Any(a => a.Key == SignParamter.Noncestr))
                {
                    paramDic.Add(request.GetQueryNameValuePairs().GetParamter(SignParamter.Noncestr));
                }
                else
                {
                    var result =  request.CreateResponse(request.CreateResponse(new ResponseBase<object>()
                          {
                              Code = "1",
                              Data = null,
                              Message = "请传递正确的Noncestr参数！",
                              Success = false
                          }));
                    result.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(result);

                } 
                #endregion
                #region Timestamp参数校验
                //Noncestr参数校验
                if (query.Any(a => a.Key == SignParamter.Timestamp))
                {
                    var timestamp = request.GetQueryNameValuePairs().GetParamter(SignParamter.Timestamp);
                    paramDic.Add(timestamp);
                    //判断时间戳是否有效
                    DateTime dt = DateTimeHelper.StampToDateTime(timestamp.Value);
                        //5分钟有效期 if ((DateTime.Now.AddMinutes(-500) <= dt) && (dt <= DateTime.Now))
                    if (true)
                        {
                        }
                        else
                        {
                            var result =  request.CreateResponse(new ResponseBase<object>()
                            {
                                Code = "1",
                                Data = null,
                                Message = "请求过期！",
                                Success = false
                            });
                            result.StatusCode = HttpStatusCode.OK;
                            return Task.FromResult<HttpResponseMessage>(result);
                        }

                   
                }
                else
                {
                    var result = request.CreateResponse(new ResponseBase<object>()
                    {
                        Code = "1",
                        Data = null,
                        Message = "请传递正确的Timestamp参数！",
                        Success = false
                    });
                    result.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(result);

                } 
                #endregion
                #region jsonParam参数如果存在，则进行sign校验，如果不存在则不进行
                //JsonParam参数如果存在，则进行sign校验，如果不存在则不进行
                if (query.Any(a => a.Key == SignParamter.JsonParam))
                {
                    //paramDic.Add(request.GetQueryNameValuePairs().GetParamter(SignParamter.JsonParam));
                    JsonParamtersToSign(paramDic, request.GetQueryNameValuePairs().GetParamter(SignParamter.JsonParam).Value.EncodingToUtf8());
                } 
                #endregion
               
                #region Sign参数校验
                //签名计算检查
                if (query.Any(a => a.Key == SignParamter.Signature))
                {
                    var signature = request.GetQueryNameValuePairs().GetParamter(SignParamter.Signature);
                     //签名计算
                    var signatureStr = SignCreate(paramDic);
                    //签名正确
                    if (signature.Value == signatureStr)
                    {

                    }
                    else
                    {
                       
                        var result = request.CreateResponse(new ResponseBase<object>()
                        {
                            Code = "2",
                            Data = null,
                            Message = "Signature签名不正确！",
                            Success = false
                        });
                        result.StatusCode = HttpStatusCode.OK;

                        return Task.FromResult<HttpResponseMessage>(result);
                    }
                }
                else
                {
                    var result = request.CreateResponse(new ResponseBase<object>()
                    {
                        Code = "2",
                        Data = null,
                        Message = "Signature签名不正确！",
                        Success = false
                    });
                    result.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(result);

                } 
                #endregion
               
                //请求参数重构
                #region 请求参数重构

                if (query.Any(a => a.Key == SignParamter.JsonParam))
                {
                    JsonData jsonParamData =
                        JsonMapper.ToObject(request.GetQueryNameValuePairs().GetParamter(SignParamter.JsonParam).Value.EncodingToUtf8());
                    string paramters = string.Empty;
                    //重新构造url参数
                    foreach (var p in jsonParamData.Keys)
                    {
                        if (string.IsNullOrEmpty(paramters))
                        {
                            paramters += string.Format("?{0}={1}", p, jsonParamData[p].ToString());

                        }
                        else
                        {
                            paramters += string.Format("&{0}={1}", p, jsonParamData[p].ToString());
                        }
                        request.Properties[p] = jsonParamData[p].ToString();
                    }
                    request.RequestUri = new Uri(request.RequestUri.ToString().Split('?')[0] + paramters);
                    //request.Content = new StringContent(request.GetQueryNameValuePairs().GetParamter(SignParamter.JsonParam).Value);
                    //request.Content.Headers.Remove("Content-Type");
                    //request.Content.Headers.Add("Content-Type", "application/json");
                    request.Properties["Model_Paramters"] =
                        request.GetQueryNameValuePairs().GetParamter(SignParamter.JsonParam).Value;
                    if (jsonParamData.Keys.Contains("Fesid"))
                    {
                        request.Properties["FesidIndentity"] = jsonParamData["Fesid"].ToString();
                    }
                    if (jsonParamData.Keys.Contains("Hno"))
                    {
                        request.Properties["FesidHno"] = jsonParamData["Hno"].ToString();
                    }
                }
                else
                {
                    request.RequestUri = new Uri(request.RequestUri.ToString().Split('?')[0]);
                    //var routeDate = request.GetRequestContext().RouteData;
                }
                #endregion

            }
           
            #endregion
            #region 请求了类型为post参数获取
            else if (request.Method == HttpMethod.Post)
            {
                content = request.Content.ReadAsStringAsync().GetAwaiter().GetResult();
               
                JsonData jd = JsonMapper.ToObject(content);

                #region AppAccount  

                if (jd.Keys.Contains(SignParamter.AppAccount) && jd[SignParamter.AppAccount].ToString().ToUpper() == "NetworkApp".ToUpper())
                {
                    paramDic.Add(new KeyValuePair<string, string>(SignParamter.AppAccount,
                        jd[SignParamter.AppAccount].ToString()));
                }
                else
                {
                    var message = request.CreateResponse(new ResponseBase<object>()
                    {
                        Code = "1",
                        Data = null,
                        Message = "请传递正确的AppAccount参数！",
                        Success = false
                    });
                    message.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(message);
                }

                #endregion

                #region Noncestr

                if (jd.Keys.Contains(SignParamter.Noncestr))
                {
                    paramDic.Add(new KeyValuePair<string, string>(SignParamter.Noncestr,
                        jd[SignParamter.Noncestr].ToString()));
                }
                else
                {
                    var result = request.CreateResponse(request.CreateResponse(new ResponseBase<object>()
                    {
                        Code = "1",
                        Data = null,
                        Message = "请传递正确的Noncestr参数！",
                        Success = false
                    }));
                    result.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(result);
                }

                #endregion

                #region Timestamp参数校验

                if (jd.Keys.Contains(SignParamter.Timestamp))
                {
                    //判断时间戳是否有效
                    DateTime dt = DateTimeHelper.StampToDateTime(jd[SignParamter.Timestamp].ToString());
                    //5分钟有效期  if ((DateTime.Now.AddMinutes(-500) <= dt) && (dt <= DateTime.Now))
                    if (true)
                        {
                        }
                        else
                        {
                            var result = request.CreateResponse(new ResponseBase<object>()
                            {
                                Code = "1",
                                Data = null,
                                Message = "请求过期！",
                                Success = false
                            });
                            result.StatusCode = HttpStatusCode.OK;
                            return Task.FromResult<HttpResponseMessage>(result);
                        }

                    
                    paramDic.Add(new KeyValuePair<string, string>(SignParamter.Timestamp,
                        jd[SignParamter.Timestamp].ToString()));
                }
                else
                {
                    var result = request.CreateResponse(new ResponseBase<object>()
                    {
                        Code = "1",
                        Data = null,
                        Message = "请传递正确的Timestamp参数！",
                        Success = false
                    });
                    result.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(result);

                }

                #endregion

                #region 签名参数构造

                //参数构造
                if (jd.Keys.Contains(SignParamter.JsonParam))
                {
                    JsonParamtersToSign(paramDic, jd[SignParamter.JsonParam]);
                }
                
               #region Sign参数校验
               
               //签名计算检查
               if (jd.Keys.Contains(SignParamter.Signature))
               {
                   var signature = jd[SignParamter.Signature].ToString();
                   //签名计算
                   var signatureStr = SignCreate(paramDic);
                   //签名正确
                   if (signature.ToString() == signatureStr)
                   {

                   }
                   else
                   {
                       var result = request.CreateResponse(new ResponseBase<object>()
                       {
                           Code = "2",
                           Data = null,
                           Message = "Signature签名不正确！",
                           Success = false
                       });
                       result.StatusCode = HttpStatusCode.OK;
                       return Task.FromResult<HttpResponseMessage>(result);
                   }
               }
               else
               {
                   var result = request.CreateResponse(new ResponseBase<object>()
                   {
                       Code = "2",
                       Data = null,
                       Message = "Signature签名不正确！",
                       Success = false
                   });
                   result.StatusCode = HttpStatusCode.OK;
                   return Task.FromResult<HttpResponseMessage>(result);

               }

               #endregion
              
                #endregion

                //request.Content = new StringContent(jd[SignParamter.JsonParam].ToJson());
                //request.Content.Headers.Add("Content-Type", "application/json");
               if (jd.Keys.Contains(SignParamter.JsonParam) && !string.IsNullOrEmpty(jd[SignParamter.JsonParam].ToJson()))
               {

                   #region Fesid和Hno拦截
                   request.Properties["Model_Paramters"] = jd[SignParamter.JsonParam].ToJson();
                   bool flagFesid = false;
                   bool flagHno = false;
                   if (jd[SignParamter.JsonParam].Keys.Contains("Fesid"))
                   {
                       request.Properties["FesidIndentity"] = jd[SignParamter.JsonParam]["Fesid"].ToString();
                       flagFesid = true;
                   }
                   if (!flagFesid)
                   {
                       if (jd[SignParamter.JsonParam].Keys.Contains("fesid"))
                       {
                           request.Properties["FesidIndentity"] = jd[SignParamter.JsonParam]["fesid"].ToString();

                       }
                   }
                   if (jd[SignParamter.JsonParam].Keys.Contains("Hno"))
                   {
                       request.Properties["FesidHno"] = jd[SignParamter.JsonParam]["Hno"].ToString();
                       flagHno = true;
                   }
                   if (!flagHno)
                   {
                       if (jd[SignParamter.JsonParam].Keys.Contains("hno"))
                       {
                           request.Properties["FesidHno"] = jd[SignParamter.JsonParam]["hno"].ToString();
                           
                       }
                   } 
                   #endregion
                }
               
            }  
            #endregion

            else
            {
                var message = request.CreateResponse(new ResponseBase<object>()
                {
                    Code = "1",
                    Data = null,
                    Message = string.Format("暂不支持{0}谓词", request.Method),
                    Success = false
                });
                message.StatusCode = HttpStatusCode.OK;
                return Task.FromResult<HttpResponseMessage>(message);
            }

           
            #region Fesid验证逻辑

           
            string fesidIndentity = string.Empty;
            //Fesid验证逻辑
            if (request.Properties.Keys.Contains("FesidIndentity"))
            {
              
                fesidIndentity = request.Properties["FesidIndentity"].ToString();
                bool flag = FesidCheck(fesidIndentity,request);
                if (!flag)
                {
                    var message = request.CreateResponse(new ResponseBase<object>()
                    {
                        Code = "1",
                        Data = null,
                        Message = "用户(Fesid)不可用。",
                        Success = false
                    });
                    message.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(message);
                }
            }  //Fesid验证逻辑
            #endregion

            #region 唯一号验证逻辑
            if (request.Properties.Keys.Contains("FesidHno"))
            {
                if (string.IsNullOrEmpty(fesidIndentity))
                {
                    var message = request.CreateResponse(new ResponseBase<object>()
                    {
                        Code = "1",
                        Data = null,
                        Message = "使用hno的方法必须同时传递正确的Fesid",
                        Success = false
                    });
                    message.StatusCode = HttpStatusCode.OK;
                    return Task.FromResult<HttpResponseMessage>(message);
                }
               
                Task task = new Task(() =>
                {
                    try
                    {
                        HnoCheck(request.Properties["FesidHno"].ToString(), fesidIndentity);
                    }
                    catch (Exception ex)
                    {
                        ILogger logger = ContainerFactory.GetInstance().GetCommonDllContainer().Resolve<ILogger>();
                        logger.Error(this.GetType(), "唯一号验证逻辑执行过程发生错误。", ex);
                    }
                   
                });
                task.Start();
            } 
            #endregion
          
            return  base.SendAsync(request, cancellationToken);
            
        }
        /// <summary>
        /// 签名所需参数部分处理
        /// </summary>
        /// <param name="paramDic"></param>
        /// <param name="jsonParamter"></param>
        private void JsonParamtersToSign(List<KeyValuePair<string, string>> paramDic,string jsonParamter)
        {
            JsonData jd = JsonMapper.ToObject(jsonParamter);

            foreach (var p in jd.Keys)
            {
                var v = jd[p];
                if (v.IsObject || v.IsArray)
                {
                   //暂时不在签名中使用
                }
                else
                {
                    paramDic.Add(new KeyValuePair<string, string>(p, jd[p].ToString()));
                }
            }
        }
        /// <summary>
        /// 签名所需参数部分处理
        /// </summary>
        /// <param name="paramDic"></param>
        /// <param name="jsonParamter"></param>
        private void JsonParamtersToSign(List<KeyValuePair<string, string>> paramDic, JsonData jsonParamter)
        {
            JsonData jd = jsonParamter;

            foreach (var p in jd.Keys)
            {
                var v = jd[p];
                if (v.IsObject || v.IsArray)
                {
                    //暂时不在签名中使用
                }
                else
                {
                    paramDic.Add(new KeyValuePair<string, string>(p, jd[p].ToString()));
                }
            }
        }
        /// <summary>
        /// 签名计算
        /// </summary>
        /// <param name="paramDic"></param>
        /// <returns></returns>
        private string SignCreate(List<KeyValuePair<string, string>> paramDic)
        {
            paramDic = paramDic.Where(p => !string.IsNullOrEmpty(p.Value)).ToList();
            paramDic.Sort((a, b) => String.Compare(a.Key, b.Key, false));
            var text = string.Concat(paramDic.Select(p => string.Concat(p.Key, p.Value)));
            var sign = EncryptHelperTwo.MD5One((appsecret + text.EncodingToUtf8()).EncodingToUtf8()).ToLower();
            return sign;
        }

        private ICacheStorage cacheStorage;
        private FS.Model.T_Fes_User fesUser;
        /// <summary>
        /// 用户是否有效判断
        /// </summary>
        /// <returns></returns>
        private bool FesidCheck(string fesid, HttpRequestMessage request)
        {
            int fesidValue;
            int.TryParse(fesid, out fesidValue);
            if (fesidValue == 0)
            {
                return false;
            }
            //判断缓存当中是否存在
            cacheStorage = ContainerFactory.GetInstance().GetCommonDllContainer().Resolve<ICacheStorage>();
            if (cacheStorage.Exists(FS.IBLL.CacheHelper.CacheKeys.CertificationUser+fesid))
            {
                fesUser =
                    cacheStorage.Get<FS.Model.T_Fes_User>(
                        FS.IBLL.CacheHelper.CacheKeys.CertificationUser+fesid).Value;
                if (fesUser != null)
                {
                    request.Properties["FesidIndentityUser"] = fesUser;
                    return true;
                }

            }
            else
            {
               
                FS.IBLL.IT_Fes_UserBLL usrBll = ContainerFactory.GetInstance().GetCommonDllContainer().Resolve<FS.IBLL.IT_Fes_UserBLL>();
                fesUser = usrBll.Find(fesidValue);
                if (fesUser != null && fesUser.InsType == 20)
                {

                    fesUser.Dncrypt();
                  
                    //插入缓存
                    cacheStorage.Set<FS.Model.T_Fes_User>(FS.IBLL.CacheHelper.CacheKeys.CertificationUser + fesid,
                        new CacheValue<FS.Model.T_Fes_User>(fesUser, true),TimeSpan.FromMinutes(30));
                    request.Properties["FesidIndentityUser"] = fesUser;
                    return true;
                }
            }
           
            return false;

        }
        /// <summary>
        /// 用户唯一号认证判断和信息补全
        /// </summary>
        /// <param name="hno"></param>
        /// <returns></returns>
        private bool HnoCheck(string hno,string fesid)
        {
            int hnoValue;
            int fesidValue;
            int.TryParse(hno, out hnoValue);
            int.TryParse(fesid, out fesidValue);
            if (hnoValue == 0)
            {
                return false;
            }

            FS.IBLL.IT_Fes_UserBLL usrBll = ContainerFactory.GetInstance().GetCommonDllContainer().Resolve<FS.IBLL.IT_Fes_UserBLL>();
           
            //判断用户是否存在
            if (fesUser == null)
            {
                return false;
            }
            //判断是否已经补全过信息
            if (fesUser.Verify == 1)
            {
                return true;
            }
            //调用新系统接口补全信息
            NewSystem.SDK.Interfaces.IEmployee employeeService = ContainerFactory.GetInstance().GetCommonDllContainer().Resolve<NewSystem.SDK.Interfaces.IEmployee>();

            FS.Model.T_Fes_User userInfo = new Model.T_Fes_User();
            //调用新系统基础信息接口
            var basicUserInfo =
                employeeService.GetEmpBasicInfo(new NewSystem.SDK.Entities.Request.EmpBasicInfoReqestModel
                {
                    uniqNo = hno
                });
            //调用新系统接口成功
            if (basicUserInfo.code == "0" && basicUserInfo.successResult != null)
            {
                string cardId = basicUserInfo.successResult.idCardNo;
                userInfo.CardId = cardId.Contains("x") ? cardId.ToUpper() : cardId;
                userInfo.Hno = Convert.ToInt32(hno);
                userInfo.Cname = basicUserInfo.successResult.empName;
                userInfo.Verify = 1;
                try
                {
                    //获取雇员当前派出所在层级信息
                    var EmpRightInfo =
                        employeeService.GetEmpRightInfo(new NewSystem.SDK.Entities.Request.GetEmpRightInfoRequest
                        {
                            uniqNo = hno
                        }, hno);
                    //新系统正确返回信息
                    if (EmpRightInfo.code == "0" && EmpRightInfo.successResult != null &&
                        EmpRightInfo.successResult.Any())
                    {
                        var rightInfo = EmpRightInfo.successResult[0];
                        userInfo.busiCustId = Utils.ToInt(rightInfo.busiCustId);
                        userInfo.acceId = Utils.ToInt(rightInfo.acceId);
                        userInfo.acceName = Utils.ToString(rightInfo.acceName);
                        userInfo.conId = Utils.ToInt(rightInfo.conId);
                        userInfo.conName = Utils.ToString(rightInfo.conName);
                        userInfo.busiCustName = Utils.ToString(rightInfo.busiCustName);
                        userInfo.custId = Utils.ToInt(rightInfo.custId);
                        userInfo.custName = Utils.ToString(rightInfo.custName);
                    }
                }
                catch (Exception ex)
                {
                    ILogger logger = ContainerFactory.GetInstance().GetCommonDllContainer().Resolve<ILogger>();
                    logger.Error(this.GetType(), "获取雇员当前派出所在层级信息过程发生错误。", ex);
                }
                userInfo.Encrypt();
                bool flag = usrBll.Update(w => w.Id == fesidValue, m => new FS.Model.T_Fes_User
                {
                    custId = userInfo.custId,
                    Hno = userInfo.Hno,
                    Cname = userInfo.Cname ?? "",
                    Verify = userInfo.Verify,
                    busiCustId = userInfo.busiCustId,
                    acceId = userInfo.acceId,
                    acceName = userInfo.acceName ??"",
                    conId = userInfo.conId,
                    conName = userInfo.conName ?? "",
                    busiCustName = userInfo.busiCustName ?? "",
                    custName = userInfo.custName ?? "",
                    CardId = userInfo.CardId
                });
                var user = usrBll.FindList(w => (w.Id == fesidValue)&&(w.InsType == 20), o => o.Id, false).Single();
                if (user != null)
                {
                    //插入缓存
                    cacheStorage.Set<FS.Model.T_Fes_User>(FS.IBLL.CacheHelper.CacheKeys.CertificationUser + fesid,
                        new CacheValue<FS.Model.T_Fes_User>(fesUser, true), TimeSpan.FromMinutes(30));
                }
                return flag;
            }
           
            return false;

        }
    }
    /// <summary>
    /// 计算签名所需要的参数
    /// </summary>
    public class SignParamter
    {
        /// <summary>
        /// 签名
        /// </summary>
        public const string Signature = "sign";
        /// <summary>
        /// 随机串
        /// </summary>
        public const string Noncestr = "noncestr";
        /// <summary>
        /// 时间戳
        /// </summary>
        public const string Timestamp = "timestamp";
        /// <summary>
        /// 客户端名称
        /// </summary>
        public const string AppAccount = "appaccount";
        /// <summary>
        /// 参数值
        /// </summary>
        public const string JsonParam = "jsonParam";



    }
}
