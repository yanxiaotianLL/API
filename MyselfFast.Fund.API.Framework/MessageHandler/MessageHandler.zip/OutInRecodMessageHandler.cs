﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using FS.Component.Logging;
using FS.Core.API.Models;

namespace FS.Core.API.MessageHandler
{
    /**********************************************************************************
     *项目名称	：FS.Core.API.MessageHandler
     *项目描述  ：
     *类名称    ：OutInRecodMessageHandler
     *版本号    ：v1.0.0
     *机器名称  ：LIUYONG-PC
     *项目名称  : OutInRecodMessageHandler
     *CLR版本   : 4.0.30319.42000
     *作者      ：liu.yong
     *创建时间  : 2017/1/7 17:23:17
     *------------------------------------变更记录--------------------------------------
     *变更描述  :
     *变更作者  :
     *变更时间  :
    ***********************************************************************************/
    /// <summary>
    /// 用于日志记录
    /// </summary>
    public class OutInRecodMessageHandler : DelegatingHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
        {
            StringBuilder sb = new StringBuilder();
            //判断请求是否等于null,记录请求信息
            DateTime dtStart = DateTime.Now;
            if (request.Content != null)
            {
                string strContent = request.Content.ReadAsStringAsync().Result;
                string strIn =string.Format("\r\n============Request-Begin==============\r\n请求地址：{0}\r\n输入：{1}\r\n请求发起时间:{2}\r\n",
                        request.RequestUri.OriginalString,strContent, DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                sb.Append(strIn);
            }
            else
            {
              string strIn =string.Format("\r\n============Request-Begin==============\r\n请求地址：{0}\r\n输入：\r\n请求发起时间:{1}\r\n",
                        request.RequestUri.OriginalString,DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                sb.Append(strIn);
            }
            return base.SendAsync(request, cancellationToken).ContinueWith<HttpResponseMessage>(task =>
            {
                //获取响应内容
                string strContent = task.Result.Content.ReadAsStringAsync().Result;
                DateTime dtEnd = DateTime.Now;
                TimeSpan ts = dtEnd - dtStart;
                string strOut = string.Format("输出：{0}\r\n响应时间:{1}\r\n请求耗时:{2}(ms)\r\n==============Request-End=============\r\n", strContent,
                  DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"),ts.TotalMilliseconds);
                sb.Append(strOut);
                Task t = new Task(() => LoggerProviderFactory.CreateLogger(LogType.log4net).Info(this.GetType(),sb.ToString()));
                t.Start();
                return task.Result;
            });
        }
    }
}
